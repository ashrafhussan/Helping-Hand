<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login Form | Helping Hand</title>
    <link rel="stylesheet" href="login.css">
  </head>
  <body>
    <div class="center">
      <h1>Login</h1>
      <form method="post">
        <div class="txt_field">
          <input type="text" name="Email" required>
          <span></span>
          <label>Email</label>
        </div>
        <div class="txt_field">
          <input type="password" name="Password" required>
          <span></span>
          <label>Password</label>
        </div>
        <div class="pass">Forgot Password?</div>
        <input type="submit" value="Login" name="searching">
        <div class="signup_link">
          Not a member? <a href="registration.php">Sign up</a>
        </div>
      </form>
    </div>

  </body>
</html>
<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "Helping_hand";
   //$name = filter_input(INPUT_POST, 'name');
   // Create connection
  $conn = mysqli_connect($servername, $username, $password, $dbname);
   // Check connection
  if (!$conn) {

    die("Connection failed: " . mysqli_connect_error());

  }
  if(isset($_POST['searching'])){

    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    $Password = filter_input(INPUT_POST, 'Password');
   // $hashed_password = password_hash($Password, PASSWORD_DEFAULT);

    $sql2 = "SELECT * FROM registration WHERE Email='$Email' AND Password='$Password'";
    $result = mysqli_query($conn, $sql2);

    if (mysqli_num_rows($result) ==1) {

      header("Location:Main.html?Email=".$Email);
      die();

    }
    else{

      echo "<br><br><center><font color=White>Wrong username or password !</font></center";
      die();

    }

  }
 ?>